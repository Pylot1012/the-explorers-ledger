# Atlas Obscura Web Scraper

A Python web scraping project that collects 100 unusual, hidden, and mysterious
places from Atlas Obscura, performs analysis, and produces a CSV plus charts.

## Requirements

- Python 3.9 or newer
- An internet connection (the script calls Atlas Obscura's public search API)

## Setup in VS Code

1. Open the folder containing `atlas_scraper.py` in VS Code.
2. (Recommended) Create a virtual environment:
   ```bash
   python -m venv .venv
   ```
   - macOS / Linux: `source .venv/bin/activate`
   - Windows (PowerShell): `.venv\Scripts\Activate.ps1`
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. (Optional) In VS Code, open the Command Palette and run
   "Python: Select Interpreter", then choose the `.venv` interpreter.

## Run

```bash
python atlas_scraper.py
```

The script takes a couple of minutes (it paginates through the Atlas Obscura
search API with polite delays).

## Output Files

All written to the current working directory:

| File | Description |
| ---- | ----------- |
| `atlas_places.csv` | 100 places × 7 columns (name, location, category, description, url, city, country) |
| `chart_categories.png` | Places per category bar chart |
| `chart_countries.png` | Top 15 countries bar chart |
| `chart_cities.png` | Top 15 cities bar chart |
| `chart_word_freq.png` | Top 20 most frequent words in place names |

## How It Works

The script uses Atlas Obscura's JSON search endpoint
(`https://www.atlasobscura.com/search?page=N`) to paginate through place
records. Each record contains a name, subtitle (used as the description),
location string, and URL.

Atlas Obscura does not expose category filters in its public API, so each place
is classified into one of three categories ("Weird & Unusual", "Hidden Gems",
"Mysterious") via keyword matching on the title and description. City and
country are parsed from the location field.
